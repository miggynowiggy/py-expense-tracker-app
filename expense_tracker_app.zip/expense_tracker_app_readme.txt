HOW TO RUN THE DEMO APP
- Open Command Prompt 

THEN ENTER THE FOLLOWING COMMANDS

- py -m venv venv

- cd venv/Scripts

- activate.bat

- pip install pyqt5 pyqt5-tools

- py app.py


OPEN THE Qt Desginer

Go to the folder: venv/Lib/site-packages/qt_applications/Qt/bin/designer.exe


TRANSLATE THE .ui FILE TO .py FILE

- pyuic5 expense_tracker.py -o expense_tracker.py